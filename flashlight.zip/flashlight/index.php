<?php echo file_get_contents("html/header.html"); ?> 
<?php echo file_get_contents("html/home.html"); ?> 
<?php echo file_get_contents("html/footer.html"); ?>
